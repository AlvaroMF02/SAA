# Introducción a Machine Learning

En este repositorio hay notebooks de Jupyter para mi clase de **Introducción a Machine Learning** en la **Universidad del Desarrollo**.

Como material utilizo los notebooks creados por [Jake Vanderplas](https://twitter.com/jakevdp) en su libro [Python Data Science Handbook](https://github.com/jakevdp/PythonDataScienceHandbook), traducidos al castellano, y en algunos casos, con datos chilenos que permiten entender mejor el contexto de los algoritmos.

Iré subiendo el material a medida que avance el curso. 

- [@carnby](https://twitter.com/carnby)